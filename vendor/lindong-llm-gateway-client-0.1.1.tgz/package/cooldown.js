// Internal state: deployment settings and caller retry policy remain separate.
const CONTENT_FIELDS = new Set(['messages', 'input', 'prompt', 'contents', 'system', 'systemInstruction']);

export function stableJSON(value) {
  return JSON.stringify(value, (_, item) => item && typeof item === 'object' && !Array.isArray(item)
    ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
}

function contentShape(value) {
  if (Array.isArray(value)) return [...new Set(value.map(item => stableJSON(contentShape(item))))].sort();
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key,
    ['role', 'type', 'mimeType', 'mime_type', 'format'].includes(key) && typeof item === 'string' ? item : contentShape(item)]));
  if (typeof value === 'string') return { kind: 'string', media: ['image', 'audio', 'video'].find(kind => value.startsWith(`data:${kind}/`)) ?? null };
  return { kind: value === null ? 'null' : typeof value };
}

export function cooldownControls(payload) {
  return Object.fromEntries(Object.entries(payload).filter(([key]) => key !== 'model').map(([key, value]) => [key,
    CONTENT_FIELDS.has(key) ? contentShape(value) : key === 'extra_body' && value && typeof value === 'object' && !Array.isArray(value)
      ? cooldownControls(value) : value]));
}

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    signal?.throwIfAborted();
    const abort = () => { clearTimeout(timer); reject(signal.reason); };
    const timer = setTimeout(() => { signal?.removeEventListener('abort', abort); resolve(); }, ms);
    signal?.addEventListener('abort', abort, { once: true });
  });
}

export class Cooldowns {
  #deadlines = new Map();
  #clock;
  #sleep;
  constructor(clock = () => performance.now(), wait = sleep) {
    this.#clock = clock;
    this.#sleep = wait;
  }

  remember(key, status, detail) {
    if (status !== 422 || detail?.code !== 'route_cooldown' || detail?.dispatch_boundary !== 'not_crossed' || detail.cooldown_cacheable !== true ||
        !Number.isSafeInteger(detail.retry_after_s) || detail.retry_after_s < 1 || detail.retry_after_s > Math.floor(Number.MAX_SAFE_INTEGER / 1000)) return;
    const now = this.#clock();
    for (const [item, until] of this.#deadlines) if (until <= now) this.#deadlines.delete(item);
    const until = Math.max(this.#deadlines.get(key) ?? now, now + detail.retry_after_s * 1000);
    this.#deadlines.delete(key);
    this.#deadlines.set(key, until);
    while (this.#deadlines.size > 128) this.#deadlines.delete(this.#deadlines.keys().next().value);
  }

  async wait(key, budgetMs, signal, exhausted) {
    const started = this.#clock();
    let waited = false;
    for (;;) {
      signal?.throwIfAborted();
      const now = this.#clock();
      const elapsed = waited ? Math.max(0, now - started) : 0;
      const delay = Math.max(0, (this.#deadlines.get(key) ?? now) - now);
      if (elapsed + delay > budgetMs) throw exhausted();
      if (!delay) return elapsed;
      waited = true;
      await this.#sleep(delay, signal);
    }
  }
}
