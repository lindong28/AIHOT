export interface RetryPolicy { readonly maxAttempts: number; readonly attemptTimeoutMs: number; readonly initialBackoffMs: number }
export interface JSONRetryPolicy { readonly maxAttempts: number }
export const DEFAULT_RETRY: Readonly<RetryPolicy>;
export const DEFAULT_JSON_RETRY: Readonly<JSONRetryPolicy>;
export interface GatewayResult<B = any> { body: B; headers: Headers; status: number; requestId?: string }
export interface GatewayClientOptions {
  baseUrl: string; project: string; mode: string;
  retry?: Partial<RetryPolicy>; jsonRetry?: Partial<JSONRetryPolicy>; fetch?: typeof globalThis.fetch;
  requestRecovery?: boolean;
}
export interface RequestOptions { requestId?: string; headers?: HeadersInit; signal?: AbortSignal }
export interface RunJsonOptions<R, T> {
  execute: (attempt: number) => R | Promise<R>;
  validate: (result: R) => T | Promise<T>;
  onInvalid?: (error: OutputValidationError, result: R, attempt: number) => void | Promise<void>;
  /** Number of completed invalid generations already durably recorded. */
  startAttempt?: number;
  signal?: AbortSignal;
}
export interface JSONResult<R, T> { value: T; result: R; attempts: number }
export function httpDeadlineMs(retry: RetryPolicy): number;
export function runJson<R, T>(options: RunJsonOptions<R, T>, policy?: Partial<JSONRetryPolicy>): Promise<JSONResult<R, T>>;
export function outputValidationError(result: GatewayResult | GatewayHTTPError): OutputValidationError | undefined;
export function parseChatJson(result: GatewayResult): unknown;
export class GatewayHTTPError extends Error implements GatewayResult {
  constructor(result: GatewayResult);
  body: any; headers: Headers; status: number; requestId?: string; result: GatewayResult;
}
export class GatewayTransportError extends Error {
  constructor(message: string, options: { cause?: unknown; requestId?: string; endpoint: string });
  requestId?: string; endpoint: string;
}
export class GatewayProtocolError extends Error {
  constructor(message: string, result?: GatewayResult);
  result?: GatewayResult;
}
export class GatewayCapabilityError extends Error {
  constructor(cause: unknown);
  preDispatch: true;
}
export class GatewayCooldownError extends Error {
  constructor(requestId: string, endpoint: string);
  preDispatch: true;
  requestId: string;
  endpoint: string;
}
export class OutputValidationError extends Error {
  constructor(message: string, options?: { code?: string; result?: unknown; cause?: unknown });
  code: string; result?: unknown;
}
export class ContentRejectedError extends Error {
  constructor(message: string, result: GatewayResult);
  result: GatewayResult;
}
export class JSONRetryExhaustedError extends Error {
  constructor(attempts: number, result?: unknown, cause?: unknown);
  attempts: number; result?: unknown;
}
export class GatewayClient {
  constructor(options: GatewayClientOptions);
  readonly retry: Readonly<RetryPolicy>;
  readonly jsonRetry: Readonly<JSONRetryPolicy>;
  readonly deadlineMs: number;
  readonly baseUrl: string;
  readonly project: string;
  readonly mode: string;
  readonly requestRecovery: boolean;
  capabilities(): Promise<{ retry_policy_versions: number[]; [key: string]: unknown }>;
  request<B = any>(endpoint: string, payload: unknown, options?: RequestOptions): Promise<GatewayResult<B>>;
  runJson<R, T>(options: RunJsonOptions<R, T>): Promise<JSONResult<R, T>>;
  chatJson<T = unknown>(options: Omit<RunJsonOptions<GatewayResult, T>, 'validate'> & { validate?: (result: GatewayResult) => T | Promise<T> }): Promise<JSONResult<GatewayResult, T>>;
}
