import { createHash, randomUUID } from 'node:crypto';
import { Cooldowns, cooldownControls, stableJSON } from './cooldown.js';

export const DEFAULT_RETRY = Object.freeze({ maxAttempts: 3, attemptTimeoutMs: 30_000, initialBackoffMs: 3_000 });
export const DEFAULT_JSON_RETRY = Object.freeze({ maxAttempts: 3 });
const ENDPOINTS = new Set(['/v1/chat/completions', '/v1/embeddings', '/v1/generateContent']);
const COOLDOWN_HEADERS = new Set(['x-llm-route', 'x-llm-allowed-routes', 'x-llm-registry-revision', 'x-llm-max-provider-attempts',
  'x-llm-expected-credential-scope', 'x-llm-expected-route', 'x-llm-expected-model', 'x-llm-expected-endpoint']);

function integer(value, name, minimum = 1) {
  if (!Number.isSafeInteger(value) || value < minimum) throw new TypeError(`${name} must be an integer >= ${minimum}`);
  return value;
}

function jsonPolicy(policy = {}) {
  if (Object.keys(policy).some(key => key !== 'maxAttempts')) throw new TypeError('Unknown JSON retry setting');
  return Object.freeze({ maxAttempts: integer(policy.maxAttempts ?? 3, 'jsonRetry.maxAttempts') });
}

export function httpDeadlineMs(retry) {
  const n = integer(retry.maxAttempts, 'maxAttempts');
  const t = integer(retry.attemptTimeoutMs, 'attemptTimeoutMs');
  const b = integer(retry.initialBackoffMs, 'initialBackoffMs', 0);
  const waits = n - 1;
  const flat = b === 0 ? waits : Math.min(waits, Math.max(0, Math.floor(Math.log2(t / b)) + 1));
  const deadline = n * t + flat * t + (waits > flat ? b * (2 ** waits - 2 ** flat) : 0) + 10_000;
  if (!Number.isSafeInteger(deadline) || deadline > 2_147_483_647) throw new TypeError('Retry policy exceeds supported HTTP deadline');
  return deadline;
}

export class GatewayHTTPError extends Error {
  constructor(result) {
    super(`Gateway returned HTTP ${result.status}`);
    this.name = 'GatewayHTTPError';
    Object.assign(this, result);
    this.result = result;
  }
}
export class GatewayTransportError extends Error {
  constructor(message, { cause, requestId, endpoint }) {
    super(message, { cause });
    this.name = 'GatewayTransportError';
    this.requestId = requestId;
    this.endpoint = endpoint;
  }
}
export class GatewayProtocolError extends Error {
  constructor(message, result) {
    super(message);
    this.name = 'GatewayProtocolError';
    this.result = result;
  }
}
export class GatewayCapabilityError extends Error {
  constructor(cause) {
    super('Gateway retry capability negotiation failed; model request was not sent', { cause });
    this.name = 'GatewayCapabilityError';
    this.preDispatch = true;
  }
}
export class GatewayCooldownError extends Error {
  constructor(requestId, endpoint) {
    super('Gateway cooldown exceeds the remaining wait budget; model request was not sent');
    this.name = 'GatewayCooldownError';
    this.preDispatch = true;
    this.requestId = requestId;
    this.endpoint = endpoint;
  }
}
export class OutputValidationError extends Error {
  constructor(message, options = {}) {
    super(message, { cause: options.cause });
    this.name = 'OutputValidationError';
    this.code = options.code ?? 'schema_invalid';
    this.result = options.result;
  }
}
export class ContentRejectedError extends Error {
  constructor(message, result) {
    super(message);
    this.name = 'ContentRejectedError';
    this.result = result;
  }
}
export class JSONRetryExhaustedError extends Error {
  constructor(attempts, result, cause) {
    super(`JSON validation budget exhausted after ${attempts} generation attempts`, { cause });
    this.name = 'JSONRetryExhaustedError';
    this.attempts = attempts;
    this.result = result;
  }
}

/** Only a Gateway compatibility parse_error represents retryable output here. */
export function outputValidationError(response) {
  if (response?.status === 502 && response.body?.error?.code === 'parse_error') {
    return new OutputValidationError('Gateway received invalid model output', { code: 'invalid_json', result: response });
  }
  return undefined;
}

/** Call after identity verification and durable saving of the complete response. */
export function parseChatJson(result) {
  const outputError = outputValidationError(result);
  if (outputError) throw outputError;
  if (result.status < 200 || result.status >= 300) throw new GatewayHTTPError(result);
  const choices = result.body?.choices;
  for (const choice of Array.isArray(choices) ? choices : []) {
    if (choice?.message?.refusal || choice?.finish_reason === 'content_filter') {
      throw new ContentRejectedError('Model output was refused or filtered', result);
    }
  }
  const message = choices?.[0]?.message;
  if (!message || message.role !== 'assistant') throw new OutputValidationError('Assistant message is missing', { code: 'assistant_missing', result });
  if (typeof message.content !== 'string' || !message.content.trim()) throw new OutputValidationError('Assistant content is empty', { code: 'content_empty', result });
  try { return JSON.parse(message.content); }
  catch (cause) { throw new OutputValidationError('Assistant content is not valid JSON', { code: 'invalid_json', result, cause }); }
}

/** execute owns request IDs and persistence; only validate can initiate another generation. */
export async function runJson({ execute, validate, onInvalid, startAttempt = 0, signal }, policy = DEFAULT_JSON_RETRY) {
  const { maxAttempts } = jsonPolicy(policy);
  integer(startAttempt, 'startAttempt', 0);
  for (let attempt = startAttempt + 1; attempt <= maxAttempts; attempt++) {
    signal?.throwIfAborted();
    const result = await execute(attempt);
    signal?.throwIfAborted();
    try {
      const value = await validate(result);
      return { value, result, attempts: attempt };
    } catch (error) {
      if (!(error instanceof OutputValidationError)) throw error;
      await onInvalid?.(error, result, attempt);
      signal?.throwIfAborted();
      if (attempt === maxAttempts) throw new JSONRetryExhaustedError(attempt, result, error);
    }
  }
  throw new JSONRetryExhaustedError(startAttempt);
}

export class GatewayClient {
  #fetch;
  #capabilities;
  #cooldowns = new Cooldowns();
  constructor({ baseUrl, project, mode, retry = {}, jsonRetry = {}, requestRecovery = false, fetch: fetchImpl = globalThis.fetch }) {
    const url = new URL(baseUrl);
    if (!['http:', 'https:'].includes(url.protocol) || url.search || url.hash || url.username || url.password) throw new TypeError('baseUrl must be an HTTP(S) URL without query, fragment, or credentials');
    if (!project || !mode) throw new TypeError('project and mode are required');
    if (Object.keys(retry).some(key => !Object.hasOwn(DEFAULT_RETRY, key))) throw new TypeError('Unknown retry setting');
    this.retry = Object.freeze({
      maxAttempts: integer(retry.maxAttempts ?? 3, 'retry.maxAttempts'),
      attemptTimeoutMs: integer(retry.attemptTimeoutMs ?? 30_000, 'retry.attemptTimeoutMs'),
      initialBackoffMs: integer(retry.initialBackoffMs ?? 3_000, 'retry.initialBackoffMs', 0),
    });
    this.jsonRetry = jsonPolicy(jsonRetry);
    this.deadlineMs = httpDeadlineMs(this.retry);
    this.baseUrl = url.toString().replace(/\/$/, '');
    this.project = project;
    this.mode = mode;
    if (typeof requestRecovery !== 'boolean') throw new TypeError('requestRecovery must be boolean');
    this.requestRecovery = requestRecovery;
    this.#fetch = fetchImpl;
    Object.freeze(this);
  }

  async #send(endpoint, payload, requestId, headers, signal, deadlineMs) {
    const controller = new AbortController();
    const abort = () => controller.abort(signal.reason);
    if (signal?.aborted) abort();
    else signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(() => controller.abort(new Error('Gateway HTTP deadline exceeded')), deadlineMs);
    let response, text;
    try {
      response = await this.#fetch(`${this.baseUrl}${endpoint}`, {
        method: payload === undefined ? 'GET' : 'POST', headers,
        body: payload === undefined ? undefined : JSON.stringify(payload),
        signal: controller.signal, redirect: 'error',
      });
      text = await response.text();
    } catch (cause) {
      throw new GatewayTransportError('Gateway HTTP request did not complete; no automatic replay was performed', { cause, requestId, endpoint });
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
    }
    let body, parsed = true;
    try { body = JSON.parse(text); } catch { body = text; parsed = false; }
    const result = { body, headers: response.headers, status: response.status, requestId };
    if (requestId !== undefined) this.#checkEcho(result);
    if (!response.ok) throw new GatewayHTTPError(result);
    if (!parsed) throw new GatewayProtocolError('Gateway returned a non-JSON HTTP response', result);
    return result;
  }

  #checkEcho(result) {
    const companions = [result.body?.llm_gateway, result.body?.error?.llm_gateway].filter(value => value !== undefined);
    if ([...result.headers.keys()].some(key => key.startsWith('x-llm-gateway-') && key !== 'x-llm-gateway-error')) {
      try {
        companions.push({
          logical_request_id: decodeURIComponent(result.headers.get('X-LLM-Gateway-Logical-Request-Id') ?? ''),
          retry_policy: JSON.parse(decodeURIComponent(result.headers.get('X-LLM-Gateway-Retry-Policy') ?? 'null')),
        });
      } catch { throw new GatewayProtocolError('Gateway identity headers are malformed', result); }
    }
    if (!companions.length && result.status >= 200 && result.status < 300) throw new GatewayProtocolError('Gateway response omitted retry policy acknowledgement', result);
    const expected = { version: 1, max_attempts: this.retry.maxAttempts, attempt_timeout_ms: this.retry.attemptTimeoutMs, initial_backoff_ms: this.retry.initialBackoffMs };
    for (const companion of companions) {
      if (companion?.logical_request_id !== result.requestId || !companion?.retry_policy ||
          Object.keys(companion.retry_policy).length !== 4 || Object.entries(expected).some(([key, value]) => companion.retry_policy[key] !== value)) {
        throw new GatewayProtocolError('Gateway response request identity or retry policy does not match the request', result);
      }
    }
  }

  async capabilities() {
    if (!this.#capabilities) {
      this.#capabilities = this.#send('/api/capabilities', undefined, undefined,
        new Headers({ 'X-LLM-Project': this.project, 'X-LLM-Mode': this.mode }), undefined, 10_000)
        .then(result => {
          if (!Array.isArray(result.body?.retry_policy_versions) || !result.body.retry_policy_versions.includes(1)) {
            throw new GatewayProtocolError('Gateway does not support retry policy version 1', result);
          }
          if (this.requestRecovery && (!Array.isArray(result.body?.request_recovery_versions) || !result.body.request_recovery_versions.includes(1))) {
            throw new GatewayProtocolError('Gateway does not support request recovery version 1', result);
          }
          return result.body;
        }).catch(error => { this.#capabilities = undefined; throw new GatewayCapabilityError(error); });
    }
    return this.#capabilities;
  }

  async request(endpoint, payload, options = {}) {
    if (Object.keys(options).some(key => !['requestId', 'headers', 'signal'].includes(key))) throw new TypeError('Unsupported per-request option; retry policy belongs to the client instance');
    endpoint = endpoint.startsWith('/') ? endpoint : `/v1/${endpoint}`;
    if (!ENDPOINTS.has(endpoint) || !payload || typeof payload !== 'object' || Array.isArray(payload) || payload.stream) throw new TypeError('Retry client supports only stateless non-stream chat, embeddings, and generateContent');
    const headers = new Headers(options.headers);
    for (const key of ['X-LLM-Request-Recovery', 'X-LLM-Retry-Policy', 'X-LLM-Retry-Wait-Budget-Ms', 'X-LLM-Project', 'X-LLM-Mode', 'X-LLM-Request-ID']) {
      if (headers.has(key)) throw new TypeError(`${key} is controlled by the client instance/requestId`);
    }
    const requestId = options.requestId ?? randomUUID();
    if (typeof requestId !== 'string' || !requestId.trim()) throw new TypeError('requestId must be non-empty');
    options.signal?.throwIfAborted();
    const capabilities = await this.capabilities();
    options.signal?.throwIfAborted();
    const cooldownsEnabled = capabilities.retry_wait_budget === true;
    let deadlineMs = this.deadlineMs, key;
    if (cooldownsEnabled) {
      key = createHash('sha256').update(stableJSON([this.baseUrl, this.project, this.mode, endpoint, payload.model, cooldownControls(payload),
        [...headers].filter(([name]) => COOLDOWN_HEADERS.has(name))])).digest('hex');
      const budgetMs = deadlineMs - this.retry.maxAttempts * this.retry.attemptTimeoutMs - 10_000;
      const elapsed = await this.#cooldowns.wait(key, budgetMs, options.signal, () => new GatewayCooldownError(requestId, endpoint));
      headers.set('X-LLM-Retry-Wait-Budget-Ms', String(Math.floor(budgetMs - elapsed)));
      deadlineMs -= elapsed;
    }
    options.signal?.throwIfAborted();
    headers.set('Content-Type', 'application/json');
    headers.set('X-LLM-Project', this.project);
    headers.set('X-LLM-Mode', this.mode);
    headers.set('X-LLM-Request-ID', requestId);
    if (this.requestRecovery) headers.set('X-LLM-Request-Recovery', '1');
    headers.set('X-LLM-Retry-Policy', JSON.stringify({ version: 1, max_attempts: this.retry.maxAttempts, attempt_timeout_ms: this.retry.attemptTimeoutMs, initial_backoff_ms: this.retry.initialBackoffMs }));
    try {
      return await this.#send(endpoint, payload, requestId, headers, options.signal, deadlineMs);
    } catch (error) {
      if (cooldownsEnabled && error instanceof GatewayHTTPError) this.#cooldowns.remember(key, error.status, error.body?.error);
      throw error;
    }
  }

  runJson(options) { return runJson(options, this.jsonRetry); }
  chatJson(options) { return this.runJson({ ...options, validate: options.validate ?? parseChatJson }); }
}
